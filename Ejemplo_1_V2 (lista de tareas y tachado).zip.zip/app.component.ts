import { Component } from '@angular/core';
import { TareaComponent } from './Tarea.component';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent {
  title="A checkList";
  arrTareas: TareaComponent[]=[];
  cantItems: number=0;

  addTarea(itemValue: string){
    if (itemValue.length>0){
      this.arrTareas.push( new TareaComponent(itemValue,false));
      this.cantItems=this.arrTareas.length;
    }else{
      alert("Debe ingresar el valor del ítem")
    }
  }

  delTarea(indice: number){
    let item: TareaComponent[];
    item=this.arrTareas.splice(indice,1);
    this.cantItems=this.arrTareas.length;
  }

}


