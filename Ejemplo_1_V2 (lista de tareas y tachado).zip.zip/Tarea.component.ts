import { Component } from '@angular/core';

@Component({
/* Componente que define la clase TareaComponent
   y que define el valor a mostrar y el estado 
   del switch del checkbox a mostrar */
})

export class TareaComponent{
  private value: string;
  private selected: boolean;

  constructor(pValue: string, pSelected: boolean){
    this.value=pValue;
    this.selected=pSelected;
  }

  getValue(){
    return this.value;
  }

  getSelected(){
    return this.selected;
  }
}