import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent {
  title="A checkList";
  arrTareas: Tarea[]=[];
  cantItems: number=0;
  i: number=0;

  addTarea(itemValue: string){
    if (itemValue.length>0){
      this.arrTareas.push( new Tarea(itemValue,false));
      this.cantItems=this.arrTareas.length;
    }else{
      alert("Debe ingresar el valor del ítem")
    }
  }

  delTarea(indice: number){
    let item: Tarea[];
    item=this.arrTareas.splice(indice,1);
  }

}

export class Tarea{
  private value: string;
  private selected: boolean;

  constructor(pValue: string, pSelected: boolean){
    this.value=pValue;
    this.selected=pSelected;
  }

  getValue(){
    return this.value;
  }

  getSelected(){
    return this.selected;
  }
}
